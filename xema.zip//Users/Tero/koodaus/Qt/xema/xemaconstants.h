#ifndef XEMACONSTANTS_H
#define XEMACONSTANTS_H

#include <QString>
/*
#ifdef Q_OS_SYMBIAN
static const QString filePath("c:/data/");
#else
//static const QString filePath("/home/tsiirone/");
static const QString filePath("C:/");
#endif
*/
//static const int OBS_SUBFIELDCOUNT = 12;


#endif // XEMACONSTANTS_H
