#include <QFile>
#include <QTextStream>
#include "modeldataloader.h"
#include "birdmodel.h"
#include "bird.h"
#include "locationmodel.h"
#include "location.h"
#include "personmodel.h"
#include "person.h"

ModelDataLoader::ModelDataLoader(QObject *parent) :
    QObject(parent)
{
}

void ModelDataLoader::loadBirdData( BirdModel *model )
{
    model->addItem( Bird( 1, "Joutsenlaji", "Cygnus (släktet)", "CYGSP", "Cygnus sp", "S" ) );
    model->addItem( Bird( 2, "Kyhmyjoutsen", "Knölsvan", "CYGOLO", "Cygnus olor", "A" ) );
    model->addItem( Bird( 3, "Mustajoutsen", "Svart svan", "CYGATR", "Cygnus atratus", "E" ) );
    QFile tiedosto( "qrc:lajilista.csv");
    QTextStream striimi(tiedosto);
}

void ModelDataLoader::loadLocationData(LocationModel *model)
{
    model->addItem( Location( "Kokkola", "Lintutorni" ) );
    model->addItem( Location( "Kokkola", "Parveke" ) );
}

void ModelDataLoader::loadPersonData(PersonModel *model)
{
    model->addItem( Person( "Toni", QString( "Uusimäki" ), true ) );
    model->addItem( Person( "Uni", QString( "Toosimäki" ), true ) );
}
